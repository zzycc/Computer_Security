import hashlib

result="'OR'"
brute_force=300000000000000000000000000000000000000

while True:
	brute_force=brute_force+1
	m=hashlib.md5()
	m.update(str(brute_force))
	hashResult=m.digest()
	pos=hashResult.upper().find(result);
	if(pos>=0):
		if(hashResult[pos+4].isdigit() and hashResult[pos+4] is not '0'):
			break
print brute_force
