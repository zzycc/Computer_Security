
print("shihjie2\0 A+")
